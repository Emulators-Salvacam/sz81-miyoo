export PATH="${PATH}:/opt/mipsel-linux-uclibc/usr/bin/"
