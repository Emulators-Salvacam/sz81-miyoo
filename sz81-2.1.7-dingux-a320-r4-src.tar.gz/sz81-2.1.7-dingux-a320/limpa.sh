find ./ -iname "*.o" -delete -print
set -v
rm sz81 sz81_2.1.7_mipsel-linux-uclibc.tar.gz
rm *~

