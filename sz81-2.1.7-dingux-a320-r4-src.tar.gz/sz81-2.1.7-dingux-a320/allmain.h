/* allmain.h - functions provided by {,x}main.c needed by common*.c.
 */

#ifndef SZ81	/* Added by Thunor */
extern void exit_program(void);
#endif
extern void update_scrn(void);
extern void check_events(void);
